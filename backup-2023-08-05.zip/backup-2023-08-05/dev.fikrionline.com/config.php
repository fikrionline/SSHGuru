<?php

//domain
$options['domain_name'] = 'dev.fikrionline.com';
$options['domain_url'] = 'https://dev.fikrionline.com';
$options['domain_scheme'] = 'https://';

//site
$options['site_name'] = 'SSH Stunnel Websockets VPN V2ray';
$options['site_logo_text'] = 'SSH Guru';
$options['site_description'] = 'Free SSH Account, Free Stunnel Server, Free Websockets Login, Free Xray Client, Free Vmess Access';
$options['main_keyword'] = 'free ssh account, free stunnel server, free websockets login, free xray client, free vmess access';

//permalink
$options['permalink_static_page'] = 'page';
$options['permalink_extension'] = '';

//feedburner username
$options['feedburner_slug'] = 'sshguru';

//country
$options['country_base'] = 'en-US';

//root path
$options['root_dir'] = dirname(__FILE__); //echo $options['root_dir'] . "<br />";

//themes
$options['template_dir'] = 'themes/pure'; //echo $options['template_dir'] . "<br />";
$options['template_url'] = $options['domain_url'].'/'.$options['template_dir']; //echo $options['template_url'] . "<br />";

//contact
$options['contact_name'] = 'SSh Guru';
$options['contact_address'] = '3618 Courtright Street Thompson, ND 58278';
$options['contact_phone'] = '701-599-1782';
$options['contact_mail'] = 'removalrequestwebmaster@gmail.com';

//locale
$options['locale'] = 'en_US';

require_once($options['root_dir'] . '/includes/minify.php');
