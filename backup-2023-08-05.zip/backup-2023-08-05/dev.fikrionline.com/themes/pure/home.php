<?php

//ads OK or NOT
define('ADS_OK', 0);

//home check
$slug_home = strtolower($uri_explode[1]);
if(strlen($slug_home) >= 1) {
    include_once($options['template_dir'].'/404.php');
    exit();
}

//meta Keywords
$meta_keyword = $options['main_keyword'];

//meta description
$meta_description = $options['site_description'];

//site name
$show['h1_title'] = $options['site_name'];
$show['head_title'] = $options['site_name'];

//canonical
$canonical = $options['domain_url'];

//pub date
$date_mod = date('d') - 1;
if($date_mod < 1) { $date_mod = 01; }
$date_pub = date('d') - 5;
if($date_pub < 1) { $date_pub = 01; }
$datePublished = date('Y-m-').$date_pub;
$dateModified = date('Y-m-').$date_mod;

//header more
$show['head_more'] = '';

$show['head_more'] .= '<meta name="robots" content="index, follow" />'."\n";
$show['head_more'] .= '<meta name="googlebot" content="index, follow" />'."\n";
$show['head_more'] .= '<meta name="msnbot" content="index, follow" />'."\n";

$show['head_more'] .= '<link rel="canonical" href="'.$canonical.'" />'."\n";
$show['head_more'] .= '<meta name="keywords" content="'.$meta_keyword.'" />'."\n";
$show['head_more'] .= '<meta name="description" content="'.$meta_description.'" />'."\n";

$show['head_more'] .= '<meta property="og:url" content="'.$canonical.'" />'."\n";
$show['head_more'] .= '<meta property="og:type" content="article" />'."\n";
$show['head_more'] .= '<meta property="og:title" content="'.$show['h1_title'].'" />'."\n";
$show['head_more'] .= '<meta property="og:description" content="'.$show['h1_title'].', '.$options['site_name'].'" />'."\n";
$show['head_more'] .= '<meta property="og:image" content="'.$options['template_url'].'/img/favicon/android-chrome-512x512.png" />'."\n";
$show['head_more'] .= '<link rel="apple-touch-icon" sizes="180x180" href="'.$options['template_url'].'/img/favicon/apple-touch-icon.png" />'."\n";
$show['head_more'] .= '<link rel="icon" type="image/png" sizes="32x32" href="'.$options['template_url'].'/img/favicon/favicon-32x32.png" />'."\n";
$show['head_more'] .= '<link rel="icon" type="image/png" sizes="16x16" href="'.$options['template_url'].'/img/favicon/favicon-16x16.png" />'."\n";
//$show['head_more'] .= '<link rel="manifest" href="/site.webmanifest">
$show['head_more'] .= '<meta property="og:image:alt" content="'.$show['h1_title'].'" />'."\n";
$show['head_more'] .= '<meta property="og:locale" content="'.$options['locale'].'" />'."\n";

if(isset($options['locale_alternate']) && is_array($options['locale_alternate']) && count($options['locale_alternate']) >= 1) {
  foreach ($options['locale_alternate'] as $language_alternate) {
    $show['head_more'] .= '<meta property="og:locale:alternate" content="'.$language_alternate.'" />'."\n";
  }
}

$show['head_more'] .= '<link rel="alternate" type="application/rss+xml" href="'.$options['domain_url'].'/rss.php" title="'.$options['site_name'].' RSS Feed">'."\n";

?><!doctype html>
<html lang="<?php echo $options['country_base']; ?>" />
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta name="description" content="Free SSH Account" />
    <title><?php echo $show['head_title']; ?></title>
    <style type="text/css"><?php require_once($options['template_dir'].'/css/all-min.css'); ?></style>
    <?php if(isset($show['head_more'])) { echo $show['head_more']; } ?>
</head>
<body>

<div class="pure-menu pure-menu-horizontal">
    <ul class="pure-menu-list">
        <li class="pure-menu-item pure-menu-selected"><a href="/" class="pure-menu-link">Home</a></li>
        <li class="pure-menu-item pure-menu-selected"><a href="/page/privacy" class="pure-menu-link">Privacy</a></li>
        <li class="pure-menu-item pure-menu-selected"><a href="/page/about" class="pure-menu-link">About</a></li>
        <li class="pure-menu-item pure-menu-selected"><a href="/page/contact" class="pure-menu-link">Contact</a></li>
    </ul>
</div>

<div class="banner">
    <h1 class="banner-head">
        <?php echo $options['site_name']; ?>
    </h1>
</div>

<div class="l-content">
    <div class="pricing-tables pure-g">
        <div class="pure-u-1 pure-u-md-1-3">
            <div class="pricing-table pricing-table-free">
                <div class="pricing-table-header">
                    <h2>SSH/TLS Stunnel US 1</h2>

                    <span class="pricing-table-price">
                        $0 <span>per month</span>
                    </span>
                </div>

                <ul class="pricing-table-list">
                    <li>Fast and Secure Access</li>
                    <li>Protocol TCP/UDP</li>
                    <li>SSL/TLS Support</li>
                    <li>Non SSL/TLS Support</li>
                    <li>Unlimited Bandwidth</li>
                </ul>

                <a href="/ssh-stunnel-us1"><button class="button-choose pure-button">Choose</button></a>
            </div>
        </div>

        <div class="pure-u-1 pure-u-md-1-3">
            <div class="pricing-table pricing-table-biz pricing-table-selected">
                <div class="pricing-table-header">
                    <h2>SSH/TLS Stunnel US 2</h2>

                    <span class="pricing-table-price">
                        $0 <span>per month</span>
                    </span>
                </div>

                <ul class="pricing-table-list">
                    <li>Unlimited bandwidth</li>
                    <li>Fast and Secure</li>
                    <li>SSL/TLS Support</li>
                    <li>PC and SmartPhone Allowed</li>
                    <li>Simple Config</li>
                </ul>

                <a href="/ssh-stunnel-us2"><button class="button-choose pure-button">Choose</button></a>
            </div>
        </div>

        <div class="pure-u-1 pure-u-md-1-3">
            <div class="pricing-table pricing-table-enterprise">
                <div class="pricing-table-header">
                    <h2>SSH/TLS Stunnel US 3</h2>

                    <span class="pricing-table-price">
                        $0 <span>per month</span>
                    </span>
                </div>

                <ul class="pricing-table-list">
                    <li>Unrestricted Access</li>
                    <li>Unlimited Bandwidth</li>
                    <li>Premium customer Support</li>
                    <li>Android and iPhone Support</li>
                    <li>Secure Connections</li>
                </ul>

                 <a href="/ssh-stunnel-us3"><button class="button-choose pure-button">Choose</button></a>
            </div>
        </div>
    </div> <!-- end pricing-tables -->

    <div class="information pure-g">
        <div class="pure-u-1 pure-u-md-1-2">
            <div class="l-box">
                <h3 class="information-head">VPN Benefits and Usage</h3>
                <p>VPN stands for Virtual Private Network. It's a technology that allows you to create a secure and encrypted connection to another network over the Internet. VPNs are commonly used to provide privacy and anonymity while browsing the internet, as well as to access resources on a network that you might not be physically connected to.</p>
                <p>When you use a VPN, your internet traffic is routed through a secure tunnel to a server operated by the VPN provider. This server can be located in a different geographic location, which can make it appear as if you are browsing the internet from that location. This feature is often used to bypass geo-restrictions, allowing users to access content that might be restricted in their own region.</p>
                <p>VPNs are also used to enhance security, especially when using public Wi-Fi networks. By encrypting your internet traffic, VPNs help protect your data from potential eavesdroppers or hackers who might be lurking on the same network.</p>
                <p>In summary, a VPN provides:
                    <br />
                    1) Privacy and Anonymity: By masking your IP address and routing your traffic through a different server, VPNs can help you maintain a level of anonymity while browsing the internet.
                    <br />
                    2) Security: VPNs encrypt your internet traffic, making it more difficult for third parties to intercept and access your data.
                    <br />
                    3) Access to Restricted Content: VPNs can help you bypass geographic restrictions and access content that might be limited to certain regions.
                    <br />
                    4) Safe Public Wi-Fi Usage: VPNs add an extra layer of security when using public Wi-Fi networks, protecting your data from potential threats.
                </p>
            </div>
        </div>

        <div class="pure-u-1 pure-u-md-1-2">
            <div class="l-box">
                <h3 class="information-head">SSH Premium Access</h3>
                <p>SSH stands for Secure Shell. It is a cryptographic network protocol used for secure remote access to and management of network devices and servers over an unsecured network. SSH provides a secure channel for communication between two systems, allowing data to be exchanged securely even over potentially insecure networks like the internet.</p>
                <p>SSH operates through a client-server architecture and uses encryption techniques to ensure confidentiality and integrity of data during transmission. It is widely used for various purposes, including:
                    <br />
                    1) Remote Command Execution: Administrators can log into remote servers and execute commands as if they were physically present at the server.
                    <br />
                    2) Secure File Transfer: SSH allows secure file transfer between systems using tools like SCP (Secure Copy) and SFTP (Secure File Transfer Protocol).
                    <br />
                    3) Tunneling: SSH can create secure tunnels that encapsulate other network protocols, such as HTTP, allowing for secure communication even in less secure environments.
                    <br />
                    4) Port Forwarding: SSH can forward network connections from a local machine to a remote server, providing a secure way to access services that are behind a firewall or on a private network.
                    <br />
                    5) Remote Desktop Access: SSH can be used for secure remote desktop access to graphical user interfaces on remote systems.
                </p>
                <p>Overall, SSH is a crucial tool for system administrators, developers, and anyone who needs to access or manage remote systems securely. It helps protect sensitive data and prevent unauthorized access to systems and networks.</p>
            </div>
        </div>

        <div class="pure-u-1 pure-u-md-1-2">
            <div class="l-box">
                <h3 class="information-head">Free SSH Websockets</h3>
                <p>SSH WebSockets refers to a technique that allows Secure Shell (SSH) traffic to be tunneled over WebSockets, a protocol primarily used for establishing communication between a web browser and a web server. SSH is a cryptographic network protocol used for secure remote access to systems and secure file transfers.</p>
                <p>SSH WebSockets can be useful in scenarios where traditional SSH connections might be blocked by firewalls or other network restrictions. By encapsulating SSH traffic within the WebSocket protocol, it becomes possible to establish SSH connections even in environments where direct SSH connections are not allowed.</p>
                <p>To achieve SSH over WebSockets, a specialized software or proxy needs to be set up on both the client and the server sides. This software acts as an intermediary, converting SSH traffic into WebSocket traffic and vice versa.</p>
                <p>It's important to note that the status and developments in the field of technology can change rapidly, so there may have been advancements or changes related to SSH WebSockets since my last update. If you're interested in implementing or learning more about SSH WebSockets, I recommend checking more recent sources and documentation for the latest information and techniques.</p>
            </div>
        </div>

        <div class="pure-u-1 pure-u-md-1-2">
            <div class="l-box">
                <h3 class="information-head">Fast SSH Tunneling Server</h3>
                <p>SSH tunneling, also known as SSH port forwarding, is a technique used to secure and route network traffic between a local host and a remote server using the Secure Shell (SSH) protocol. It enables you to establish a secure communication channel over an untrusted network, such as the internet, by encapsulating the data in an encrypted SSH connection.</p>
                <p>SSH tunneling can serve several purposes:
                    <br />
                    1) Secure Data Transmission: SSH tunneling encrypts the data being transmitted between the local and remote ends, providing confidentiality and integrity to the communication.
                    <br />
                    2) Bypass Firewalls and Access Restrictions: SSH tunneling can be used to bypass network restrictions imposed by firewalls or content filters, allowing you to access resources that would otherwise be blocked.
                    <br />
                    3) Local and Remote Port Forwarding: With local and remote port forwarding, you can redirect traffic from a port on your local machine to a specific port on a remote server. This is useful for accessing services on a remote server that are not directly accessible from your local network.
                    <br />
                    4) Dynamic Port Forwarding (SOCKS Proxy): This technique sets up a dynamic forwarding where your local machine acts as a SOCKS proxy server. This allows you to route your web traffic through the remote server, providing an added layer of anonymity and security.
                </p>
            </div>
        </div>
    </div> <!-- end information -->
</div> <!-- end l-content -->

<div class="footer l-box">
    <p>
        <a href="<?php echo $options['domain_url']; ?>" title="<?php echo $options['site_name']; ?>"><?php echo $options['site_logo_text']; ?></a> | 
        <a href="<?php echo $options['domain_url']; ?>/<?php echo $options['permalink_static_page']; ?>/tos">TOS</a> | 
        <a href="<?php echo $options['domain_url']; ?>/<?php echo $options['permalink_static_page']; ?>/privacy">Privacy</a> | 
        <a href="<?php echo $options['domain_url']; ?>/<?php echo $options['permalink_static_page']; ?>/about">About</a> |
        <a href="<?php echo $options['domain_url']; ?>/<?php echo $options['permalink_static_page']; ?>/contact">Contact</a>
    </p>
</div>

</body>
</html>
