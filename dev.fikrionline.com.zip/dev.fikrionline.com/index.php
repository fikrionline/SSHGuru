<?php


ini_set('display_errors',1);
ini_set('display_startup_errors',1);
error_reporting(-1);


//start for minify
ob_start();

//include config
require_once('./config.php');

//redirect prety permalink
if(isset($_GET['search']) && $_GET['search'] != '') {
  $keyword_original = strtolower(str_replace(array('+', '-', '_'), ' ', $_GET['search']));
  $keyword_original = trim(preg_replace("/\s+/", " ", $keyword_original));
  $keyword_permalink = str_replace(' ', '-', $keyword_original);
  $urlredirect = $options['domain_url'].'/'.$options['permalink_search'].'/'.$keyword_permalink.$options['permalink_extension'];
  header("HTTP/1.1 301 Moved Permanently");
  header("Location: $urlredirect");
  exit();
}

//get permalink
$uri_explode = explode('/', $_SERVER['REQUEST_URI']);
if($uri_explode[1] == '' || $uri_explode[1] == 'index.php') {
	include_once($options['template_dir'].'/home.php');
} elseif($uri_explode[1] == $options['permalink_static_page']) {
	include_once($options['template_dir'].'/page.php');
} elseif($uri_explode[1] == $options['permalink_search']) {
  include_once($options['template_dir'].'/search.php');
} elseif($uri_explode[1] == $options['permalink_sitemap']) {
  include_once($options['template_dir'].'/sitemap.php');
} else {
	include_once($options['template_dir'].'/404.php');
}

$content = ob_get_clean();
//$content = wp_html_compression_finish(ob_get_clean());
echo $content;
